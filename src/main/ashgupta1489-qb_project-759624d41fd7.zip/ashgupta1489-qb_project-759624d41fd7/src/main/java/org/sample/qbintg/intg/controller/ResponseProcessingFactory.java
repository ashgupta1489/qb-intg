package org.sample.qbintg.intg.controller;

public class ResponseProcessingFactory {

}
