package org.sample.qbintg.repository;

public interface IDataRepository {

}
