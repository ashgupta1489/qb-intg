package org.sample.qbintg.intg.model;

public class VendorModelView {

}
