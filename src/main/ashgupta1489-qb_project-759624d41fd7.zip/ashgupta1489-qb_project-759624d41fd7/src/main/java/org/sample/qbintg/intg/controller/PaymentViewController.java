package org.sample.qbintg.intg.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class PaymentViewController {

	
}
